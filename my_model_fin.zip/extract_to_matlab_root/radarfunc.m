function range = radarfunc(tgtposx,tgtposz,msposx,msposz,v_tgtx,v_tgtz,Vx,Vz,pulse_bw,prf,pfa,fs,rec_gain,rnf,num_pulse_int,tx_gain,fc,peak_power,fr,tgtrcs,rseed,max_range)
tic

    %pd = 0.9;            % Probability of detection
    %pfa = 1e-6;          % Probability of false alarm
    %max_range = 10000;    % Maximum unambiguous range
    %range_res = 25;      % Required range resolution
    %tgt_rcs = 1;         % Required target radar cross section
    
    
    prop_speed = physconst('LightSpeed'); %%  % Propagation speed
    %pulse_bw = prop_speed/(2*range_res); %input   % Pulse bandwidth
    pulse_width = 1/pulse_bw; %%               % Pulse width
    %prf = prop_speed/(2*max_range); %input        % Pulse repetition frequency
    %fs = 2*pulse_bw;   %input                     % Sampling rate
    waveform = phased.RectangularWaveform(...
        'PulseWidth',1/pulse_bw,...
        'PRF',prf,...
        'SampleRate',fs);
    
    
    
    %tgtposx=tgtposx
    %tgtposz=tgtposz
    %msposx=msposx
    %msposz=msposz
    %v_tgtx=v_tgtx
    %v_tgtz=v_tgtz
    %Vx=Vx
    %Vz=Vz
    %pulse_bw=pulse_bw
    %prf=prf
    %pfa=pfa
    %fs=fs
    %rec_gain=rec_gain
    %rnf=rnf
    %num_pulse_int=num_pulse_int
    %tx_gain=tx_gain
    %fc=fc
    %peak_power=peak_power
    %fr=fr
    %tgtrcs=tgtrcs
    %rseed=rseed
    %max_range=max_range
    
    
    
    noise_bw = pulse_bw; %%
    
    receiver = phased.ReceiverPreamp(...
        'Gain',rec_gain,...                   %input
        'NoiseFigure',rnf,...             %input
        'SampleRate',fs,...
        'EnableInputPort',true);
    
    
    
    
    
    %num_pulse_int = 10; %input
    
    %snr_min = albersheim(pd, pfa, num_pulse_int); 
    
    %tx_gain = 20; %input
    
    %fc = 10e9; %input
    lambda = prop_speed/fc; %%
    
    %peak_power = ((4*pi)^3*noisepow(1/pulse_width)*max_range^4*...
        %db2pow(snr_min))/(db2pow(2*tx_gain)*tgt_rcs*lambda^2);
    
    
    transmitter = phased.Transmitter(...
        'Gain',tx_gain,...
        'PeakPower',peak_power,...
        'InUseOutputPort',true);
    fr=fr.';
    antenna = phased.IsotropicAntennaElement(...
        'FrequencyRange',fr);     %input ex [0 10]
    
    sensormotion = phased.Platform(...
        'InitialPosition',[round(msposx); 0; round(msposz)],...
        'Velocity',[round(Vx); 0; round(Vz)]);
    
    radiator = phased.Radiator(...
        'Sensor',antenna,...
        'OperatingFrequency',fc);
    
    collector = phased.Collector(...
        'Sensor',antenna,...
        'OperatingFrequency',fc);
    
    
    tgtpos = [round(tgtposx);0;round(tgtposz)];
    tgtvel = [round(v_tgtx);round(v_tgtz);0];
    tgtmotion = phased.Platform('InitialPosition',tgtpos,'Velocity',tgtvel);
    
    %tgtrcs = 1.6; %input
    target = phased.RadarTarget('MeanRCS',tgtrcs,'OperatingFrequency',fc);
    
    channel = phased.FreeSpace(...
        'SampleRate',fs,...
        'TwoWayPropagation',true,...
        'OperatingFrequency',fc);
    
    fast_time_grid = unigrid(0,1/fs,1/prf,'[)');
    slow_time_grid = (0:num_pulse_int-1)/prf;
    
    
    receiver.SeedSource = 'Property'; %%
    receiver.Seed = rseed; %input ex 2007
    
    % Pre-allocate array for improved processing speed
    rxpulses = zeros(numel(fast_time_grid),num_pulse_int);
    
    for m = 1:num_pulse_int
    
        % Update sensor and target positions
        [sensorpos,sensorvel] = sensormotion(1/prf);
        [tgtpos,tgtvel] = tgtmotion(1/prf);
    
        % Calculate the target angles as seen by the sensor
        [tgtrng,tgtang] = rangeangle(tgtpos,sensorpos);
    
        % Simulate propagation of pulse in direction of targets
        pulse = waveform();
        [txsig,txstatus] = transmitter(pulse);
        txsig = radiator(txsig,tgtang);
        
        txsig = channel(txsig,sensorpos,tgtpos,sensorvel,tgtvel);
    
        % Reflect pulse off of targets
        tgtsig = target(txsig);
    
        % Receive target returns at sensor
        rxsig = collector(tgtsig,tgtang);
        rxpulses(:,m) = receiver(rxsig,~(txstatus>0));
    end
    
    npower = noisepow(noise_bw,receiver.NoiseFigure,...
        receiver.ReferenceTemperature);
    threshold = npower * db2pow(npwgnthresh(pfa,num_pulse_int,'noncoherent'));
    
    
    
    
    matchingcoeff = getMatchedFilter(waveform);
    matchedfilter = phased.MatchedFilter(...
        'Coefficients',matchingcoeff,...
        'GainOutputPort',true);
    [rxpulses, mfgain] = matchedfilter(rxpulses);
    
    matchingdelay = size(matchingcoeff,1)-1;
    rxpulses = buffer(rxpulses(matchingdelay+1:end),size(rxpulses,1));
    
    threshold = threshold * db2pow(mfgain);
    
    
    range_gates = prop_speed*fast_time_grid/2;
    
    tvg = phased.TimeVaryingGain(...
        'RangeLoss',2*fspl(range_gates,lambda),...
        'ReferenceLoss',2*fspl(max_range,lambda));
    
    rxpulses = tvg(rxpulses);
    
    
    rxpulses = pulsint(rxpulses,'noncoherent');
    
  
   
    [~,range_detect] = findpeaks(rxpulses,'MinPeakHeight',sqrt(threshold));
    
    range = round(range_gates(range_detect));
    if isempty(range)
        range=-1
    
    else    
        range=range(1)
    
    
toc
end
