function [pulse_bw,prf,pfa,fs,rec_gain,rnf,num_pulse_int,tx_gain,fc,peak_power,fr,tgtrcs,rseed,max_range] = radarcalc(pd,pfa,max_range,range_res,tgt_rcs,rec_gain,rnf,num_pulse_int,tx_gain,fc,fr,rseed)
    tic
    prop_speed = physconst('LightSpeed');
    pulse_bw = prop_speed/(2*range_res);
    pulse_width = 1/pulse_bw;
    prf = prop_speed/(2*max_range);
    pfa=pfa
    fs = 2*pulse_bw;
    num_pulse_int=num_pulse_int
    snr_min = albersheim(pd, pfa, num_pulse_int);
    tx_gain=tx_gain
    fc=fc
    lambda = prop_speed/fc;
    peak_power = ((4*pi)^3*noisepow(1/pulse_width)*max_range^4*...
        db2pow(snr_min))/(db2pow(2*tx_gain)*tgt_rcs*lambda^2);
    fr=fr
    tgtrcs=tgt_rcs
    rseed=rseed
    
    
    
    toc
end
